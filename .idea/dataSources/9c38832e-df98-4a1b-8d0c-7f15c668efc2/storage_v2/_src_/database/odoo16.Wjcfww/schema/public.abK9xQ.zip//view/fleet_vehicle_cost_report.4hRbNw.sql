create view fleet_vehicle_cost_report
            (id, company_id, vehicle_id, name, driver_id, fuel_type, date_start, vehicle_type, cost, cost_type) as
WITH service_costs AS (SELECT ve.id                                AS vehicle_id,
                              ve.company_id,
                              ve.name,
                              ve.driver_id,
                              ve.fuel_type,
                              date(date_trunc('month'::text, d.d)) AS date_start,
                              vem.vehicle_type,
                              COALESCE(sum(se.amount), 0::numeric) AS cost,
                              'service'::text                      AS cost_type
                       FROM fleet_vehicle ve
                                JOIN fleet_vehicle_model vem ON vem.id = ve.model_id
                                CROSS JOIN generate_series(((SELECT min(fleet_vehicle_log_services.date) AS min
                                                             FROM fleet_vehicle_log_services))::timestamp without time zone,
                                                           CURRENT_DATE + '1 mon'::interval, '1 mon'::interval) d(d)
                                LEFT JOIN fleet_vehicle_log_services se ON se.vehicle_id = ve.id AND
                                                                           date_trunc('month'::text, se.date::timestamp with time zone) =
                                                                           date_trunc('month'::text, d.d)
                       WHERE ve.active
                         AND se.active
                         AND se.state::text <> 'cancelled'::text
                       GROUP BY ve.id, ve.company_id, vem.vehicle_type, ve.name, (date(date_trunc('month'::text, d.d))),
                                d.d
                       ORDER BY ve.id, (date(date_trunc('month'::text, d.d)))),
     contract_costs AS (SELECT ve.id                                         AS vehicle_id,
                               ve.company_id,
                               ve.name,
                               ve.driver_id,
                               ve.fuel_type,
                               date(date_trunc('month'::text, d.d))          AS date_start,
                               vem.vehicle_type,
                               COALESCE(sum(co.amount), 0::numeric) + COALESCE(sum(cod.cost_generated * EXTRACT(day FROM
                                                                                                                LEAST(
                                                                                                                        date_trunc('month'::text, d.d) +
                                                                                                                        '1 mon'::interval,
                                                                                                                        cod.expiration_date::timestamp without time zone) -
                                                                                                                GREATEST(
                                                                                                                        date_trunc('month'::text, d.d),
                                                                                                                        cod.start_date::timestamp without time zone))),
                                                                               0::numeric) +
                               COALESCE(sum(com.cost_generated), 0::numeric) +
                               COALESCE(sum(coy.cost_generated), 0::numeric) AS cost,
                               'contract'::text                              AS cost_type
                        FROM fleet_vehicle ve
                                 JOIN fleet_vehicle_model vem ON vem.id = ve.model_id
                                 CROSS JOIN generate_series(((SELECT min(fleet_vehicle.acquisition_date) AS min
                                                              FROM fleet_vehicle))::timestamp without time zone,
                                                            CURRENT_DATE + '1 mon'::interval, '1 mon'::interval) d(d)
                                 LEFT JOIN fleet_vehicle_log_contract co ON co.vehicle_id = ve.id AND
                                                                            date_trunc('month'::text, co.date::timestamp with time zone) =
                                                                            date_trunc('month'::text, d.d)
                                 LEFT JOIN fleet_vehicle_log_contract cod ON cod.vehicle_id = ve.id AND
                                                                             date_trunc('month'::text, cod.start_date::timestamp with time zone) <=
                                                                             date_trunc('month'::text, d.d) AND
                                                                             date_trunc('month'::text,
                                                                                        cod.expiration_date::timestamp with time zone) >=
                                                                             date_trunc('month'::text, d.d) AND
                                                                             cod.cost_frequency::text = 'daily'::text
                                 LEFT JOIN fleet_vehicle_log_contract com ON com.vehicle_id = ve.id AND
                                                                             date_trunc('month'::text, com.start_date::timestamp with time zone) <=
                                                                             date_trunc('month'::text, d.d) AND
                                                                             date_trunc('month'::text,
                                                                                        com.expiration_date::timestamp with time zone) >=
                                                                             date_trunc('month'::text, d.d) AND
                                                                             com.cost_frequency::text = 'monthly'::text
                                 LEFT JOIN fleet_vehicle_log_contract coy
                                           ON coy.vehicle_id = ve.id AND d.d >= coy.start_date AND
                                              d.d <= coy.expiration_date AND
                                              date_part('month'::text, coy.date) = date_part('month'::text, d.d) AND
                                              coy.cost_frequency::text = 'yearly'::text
                        WHERE ve.active
                        GROUP BY ve.id, ve.company_id, vem.vehicle_type, ve.name,
                                 (date(date_trunc('month'::text, d.d))), d.d
                        ORDER BY ve.id, (date(date_trunc('month'::text, d.d))))
SELECT row_number() OVER (ORDER BY vehicle_id) AS id,
       company_id,
       vehicle_id,
       name,
       driver_id,
       fuel_type,
       date_start,
       vehicle_type,
       cost,
       cost_type
FROM (SELECT sc.company_id,
             sc.vehicle_id,
             sc.name,
             sc.driver_id,
             sc.fuel_type,
             sc.date_start,
             sc.vehicle_type,
             sc.cost,
             'service'::text AS cost_type
      FROM service_costs sc
      UNION ALL
      SELECT cc.company_id,
             cc.vehicle_id,
             cc.name,
             cc.driver_id,
             cc.fuel_type,
             cc.date_start,
             cc.vehicle_type,
             cc.cost,
             'contract'::text AS cost_type
      FROM contract_costs cc) c;

alter table fleet_vehicle_cost_report
    owner to odoo16;

