create view vendor_delay_report
            (id, date, purchase_line_id, product_id, category_id, partner_id, qty_total, qty_on_time) as
SELECT m.id,
       m.date,
       m.purchase_line_id,
       m.product_id,
       min(pc.id)         AS category_id,
       min(po.partner_id) AS partner_id,
       min(m.product_qty) AS qty_total,
       sum(
               CASE
                   WHEN m.state::text = 'done'::text AND pol.date_planned::date >= m.date::date
                       THEN ml.qty_done / ml_uom.factor * pt_uom.factor
                   ELSE 0::numeric
                   END)   AS qty_on_time
FROM stock_move m
         JOIN purchase_order_line pol ON pol.id = m.purchase_line_id
         JOIN purchase_order po ON po.id = pol.order_id
         JOIN product_product p ON p.id = m.product_id
         JOIN product_template pt ON pt.id = p.product_tmpl_id
         JOIN uom_uom pt_uom ON pt_uom.id = pt.uom_id
         JOIN product_category pc ON pc.id = pt.categ_id
         LEFT JOIN stock_move_line ml ON ml.move_id = m.id
         LEFT JOIN uom_uom ml_uom ON ml_uom.id = ml.product_uom_id
GROUP BY m.id;

alter table vendor_delay_report
    owner to odoo16;

