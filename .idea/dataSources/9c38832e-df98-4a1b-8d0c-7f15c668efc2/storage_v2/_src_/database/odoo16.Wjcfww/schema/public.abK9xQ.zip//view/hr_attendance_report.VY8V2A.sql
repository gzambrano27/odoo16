create view hr_attendance_report (id, department_id, employee_id, company_id, check_in, worked_hours, overtime_hours) as
SELECT hra.id,
       hr_employee.department_id,
       hra.employee_id,
       hr_employee.company_id,
       hra.check_in,
       hra.worked_hours,
       COALESCE(ot.duration, 0::double precision) AS overtime_hours
FROM (SELECT hr_attendance.id,
             row_number() OVER (PARTITION BY hr_attendance.employee_id, (hr_attendance.check_in::date))                                     AS ot_check,
             hr_attendance.employee_id,
             ((hr_attendance.check_in AT TIME ZONE 'utc'::text) AT TIME ZONE (((SELECT calendar.tz
                                                                                FROM resource_calendar calendar
                                                                                         JOIN hr_employee employee ON employee.id = hr_attendance.employee_id
                                                                                WHERE calendar.id = employee.resource_calendar_id))))::date AS check_in,
             hr_attendance.worked_hours
      FROM hr_attendance) hra
         LEFT JOIN hr_employee ON hr_employee.id = hra.employee_id
         LEFT JOIN hr_attendance_overtime ot
                   ON hra.ot_check = 1 AND ot.employee_id = hra.employee_id AND ot.date = hra.check_in AND
                      ot.adjustment = false;

alter table hr_attendance_report
    owner to odoo16;

