create view hr_timesheet_attendance_report
            (id, user_id, date, company_id, total_attendance, total_timesheet, total_difference, timesheets_cost,
             attendance_cost, cost_difference)
as
SELECT max(id)                                                                                        AS id,
       user_id,
       date,
       company_id,
       COALESCE(sum(attendance), 0::double precision)                                                 AS total_attendance,
       COALESCE(sum(timesheet), 0::double precision)                                                  AS total_timesheet,
       COALESCE(sum(attendance), 0::double precision) -
       COALESCE(sum(timesheet), 0::double precision)                                                  AS total_difference,
       NULLIF(sum(timesheet) * emp_cost::double precision,
              0::double precision)                                                                    AS timesheets_cost,
       NULLIF(sum(attendance) * emp_cost::double precision,
              0::double precision)                                                                    AS attendance_cost,
       NULLIF((COALESCE(sum(attendance), 0::double precision) - COALESCE(sum(timesheet), 0::double precision)) *
              emp_cost::double precision, 0::double precision)                                        AS cost_difference
FROM (SELECT - hr_attendance.id           AS id,
             hr_employee.hourly_cost      AS emp_cost,
             resource_resource.user_id,
             hr_attendance.worked_hours   AS attendance,
             NULL::double precision       AS timesheet,
             hr_attendance.check_in::date AS date,
             resource_resource.company_id
      FROM hr_attendance
               LEFT JOIN hr_employee ON hr_employee.id = hr_attendance.employee_id
               LEFT JOIN resource_resource ON resource_resource.id = hr_employee.resource_id
      UNION ALL
      SELECT ts.id,
             hr_employee.hourly_cost AS emp_cost,
             ts.user_id,
             NULL::double precision  AS attendance,
             ts.unit_amount          AS timesheet,
             ts.date,
             ts.company_id
      FROM account_analytic_line ts
               LEFT JOIN hr_employee ON hr_employee.id = ts.employee_id
      WHERE ts.project_id IS NOT NULL) t
GROUP BY user_id, date, company_id, emp_cost
ORDER BY date;

alter table hr_timesheet_attendance_report
    owner to odoo16;

