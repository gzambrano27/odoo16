create view mailing_trace_report
            (id, name, mailing_type, campaign, scheduled_date, state, email_from, scheduled, sent, delivered, error,
             bounced, canceled, opened, replied, clicked)
as
SELECT min(trace.id)                                                                                                                                                     AS id,
       utm_source.name,
       mailing.mailing_type,
       utm_campaign.name                                                                                                                                                 AS campaign,
       trace.create_date                                                                                                                                                 AS scheduled_date,
       mailing.state,
       mailing.email_from,
       count(trace.id)                                                                                                                                                   AS scheduled,
       count(trace.sent_datetime)                                                                                                                                        AS sent,
       count(trace.id) - count(trace.trace_status) FILTER (WHERE trace.trace_status::text = ANY
                                                                 (ARRAY ['error'::character varying, 'bounce'::character varying, 'cancel'::character varying]::text[])) AS delivered,
       count(trace.trace_status)
       FILTER (WHERE trace.trace_status::text = 'error'::text)                                                                                                           AS error,
       count(trace.trace_status)
       FILTER (WHERE trace.trace_status::text = 'bounce'::text)                                                                                                          AS bounced,
       count(trace.trace_status)
       FILTER (WHERE trace.trace_status::text = 'cancel'::text)                                                                                                          AS canceled,
       count(trace.trace_status)
       FILTER (WHERE trace.trace_status::text = 'open'::text)                                                                                                            AS opened,
       count(trace.trace_status)
       FILTER (WHERE trace.trace_status::text = 'reply'::text)                                                                                                           AS replied,
       count(trace.links_click_datetime)                                                                                                                                 AS clicked
FROM mailing_trace trace
         LEFT JOIN mailing_mailing mailing ON trace.mass_mailing_id = mailing.id
         LEFT JOIN utm_campaign utm_campaign ON mailing.campaign_id = utm_campaign.id
         LEFT JOIN utm_source utm_source ON mailing.source_id = utm_source.id
GROUP BY trace.create_date, utm_source.name, utm_campaign.name, mailing.mailing_type, mailing.state, mailing.email_from;

alter table mailing_trace_report
    owner to odoo16;

