create view timesheets_analysis_report
            (id, name, user_id, project_id, task_id, ancestor_task_id, employee_id, manager_id, company_id,
             department_id, currency_id, date, amount, unit_amount)
as
SELECT id,
       name,
       user_id,
       project_id,
       task_id,
       ancestor_task_id,
       employee_id,
       manager_id,
       company_id,
       department_id,
       currency_id,
       date,
       amount,
       unit_amount
FROM account_analytic_line a
WHERE project_id IS NOT NULL;

alter table timesheets_analysis_report
    owner to odoo16;

